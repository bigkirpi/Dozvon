package ru.ktzvonit.app

object LocalSpamDatabase {
    // Добавляйте проверенные номера в нормализованном виде (только цифры).
    private val entries = mapOf(
        "78005553535" to "Тестовая запись — замените реальной проверенной меткой"
    )
    fun lookup(digits: String): String? = entries[digits]
}
