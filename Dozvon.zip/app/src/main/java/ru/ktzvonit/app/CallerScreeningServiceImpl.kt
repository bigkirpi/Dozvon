package ru.ktzvonit.app

import android.telecom.Call
import android.telecom.CallScreeningService

class CallerScreeningServiceImpl : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        val number = details.handle?.schemeSpecificPart.orEmpty()
        val digits = number.filter { it.isDigit() }
        val knownSpam = LocalSpamDatabase.lookup(digits) != null

        // Не блокируем вызовы автоматически: только пропускаем их.
        // Расширение: показать уведомление с меткой после добавления разрешения POST_NOTIFICATIONS.
        val response = CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()
        respondToCall(details, response)
    }
}
