package ru.ktzvonit.app

import android.app.Activity
import android.os.Bundle
import android.widget.*

class NumberCheckActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val p = (20 * resources.displayMetrics.density).toInt()
            setPadding(p, p, p, p)
        }
        val input = EditText(this).apply { hint = "Введите номер телефона"; inputType = 3 }
        val result = TextView(this).apply { textSize = 16f }
        box.addView(TextView(this).apply { text = "Проверка номера"; textSize = 22f })
        box.addView(input)
        box.addView(Button(this).apply {
            text = "Проверить локальную базу"
            setOnClickListener {
                val number = input.text.toString().filter { it.isDigit() }
                val tags = LocalSpamDatabase.lookup(number)
                result.text = if (tags == null) {
                    "В локальной базе совпадений нет. Это не гарантирует, что номер безопасен."
                } else {
                    "Метка: $tags"
                }
            }
        })
        box.addView(result)
        setContentView(box)
    }
}
