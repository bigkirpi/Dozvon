package ru.ktzvonit.app

import android.app.Activity
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = (20 * resources.displayMetrics.density).toInt()
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }
        layout.addView(TextView(this).apply {
            text = "Супердозвон"
            textSize = 28f
        })
        layout.addView(TextView(this).apply {
            text = "\nОпределитель звонков и голосовой помощник.\n"
            textSize = 16f
        })
        layout.addView(Button(this).apply {
            text = "Поговорить с помощником"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, VoiceAssistantActivity::class.java))
            }
        })
        layout.addView(Button(this).apply {
            text = "Включить определение звонков"
            setOnClickListener { requestScreeningRole() }
        })
        layout.addView(Button(this).apply {
            text = "Проверить номер"
            setOnClickListener {
                startActivity(Intent(this@MainActivity, NumberCheckActivity::class.java))
            }
        })
        setContentView(layout)
    }

    private fun requestScreeningRole() {
        val rm = getSystemService(Context.ROLE_SERVICE) as RoleManager
        if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING) &&
            !rm.isRoleHeld(RoleManager.ROLE_CALL_SCREENING)) {
            startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING), 10)
        }
    }
}
